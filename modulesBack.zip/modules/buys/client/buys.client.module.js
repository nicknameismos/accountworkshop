(function (app) {
  'use strict';

  app.registerModule('buys');
}(ApplicationConfiguration));
