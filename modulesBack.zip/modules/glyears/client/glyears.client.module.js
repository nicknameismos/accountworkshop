(function (app) {
  'use strict';

  app.registerModule('glyears');
}(ApplicationConfiguration));
