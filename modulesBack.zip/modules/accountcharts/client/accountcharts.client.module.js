(function (app) {
  'use strict';

  app.registerModule('accountcharts');
}(ApplicationConfiguration));
