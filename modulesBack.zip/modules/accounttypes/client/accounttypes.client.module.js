(function (app) {
  'use strict';

  app.registerModule('accounttypes');
}(ApplicationConfiguration));
