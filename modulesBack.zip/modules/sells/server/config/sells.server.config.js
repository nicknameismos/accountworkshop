'use strict';

/**
 * Module dependencies
 */
var path = require('path'),
  config = require(path.resolve('./config/config'));

/**
 * Sells module init function.
 */
module.exports = function (app, db) {

};
