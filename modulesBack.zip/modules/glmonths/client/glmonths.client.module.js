(function (app) {
  'use strict';

  app.registerModule('glmonths');
}(ApplicationConfiguration));
