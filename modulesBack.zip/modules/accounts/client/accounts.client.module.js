(function (app) {
  'use strict';

  app.registerModule('accounts');
}(ApplicationConfiguration));
